| Characteristic | TNBC (Label=1) | Luminal A (Label=0) |
| --- | --- | --- |
| Age at diagnosis (years) | 54.9 +/- 12.0 (median 53.0, range 29-90, n=153) | 53.5 +/- 8.8 (median 53.0, range 37-71, n=153) |
| **Race** |  |  |
|   WHITE | 88 (57.5%) | 119 (77.8%) |
|   BLACK OR AFRICAN AMERICAN | 50 (32.7%) | 15 (9.8%) |
|   ASIAN | 8 (5.2%) | 13 (8.5%) |
|   Missing / Not reported | 7 (4.6%) | 6 (3.9%) |
| **Ethnicity** |  |  |
|   NOT HISPANIC OR LATINO | 127 (83.0%) | 122 (79.7%) |
|   Missing / Not reported | 19 (12.4%) | 24 (15.7%) |
|   HISPANIC OR LATINO | 7 (4.6%) | 7 (4.6%) |
| **AJCC pathological stage** |  |  |
|   Stage IIA | 72 (47.1%) | 43 (28.1%) |
|   Stage IIB | 25 (16.3%) | 38 (24.8%) |
|   Stage IIIA | 14 (9.2%) | 33 (21.6%) |
|   Stage I | 13 (8.5%) | 13 (8.5%) |
|   Stage IA | 16 (10.5%) | 8 (5.2%) |
|   Stage IIIC | 4 (2.6%) | 11 (7.2%) |
|   Stage IIIB | 3 (2.0%) | 3 (2.0%) |
|   Stage IV | 2 (1.3%) | 2 (1.3%) |
|   Missing / Not reported | 3 (2.0%) | 0 (0.0%) |
|   Stage II | 1 (0.7%) | 1 (0.7%) |
|   Stage IB | 0 (0.0%) | 1 (0.7%) |
| **Surgical procedure (first)** |  |  |
|   Modified Radical Mastectomy | 37 (24.2%) | 50 (32.7%) |
|   Lumpectomy | 51 (33.3%) | 29 (19.0%) |
|   Simple Mastectomy | 37 (24.2%) | 36 (23.5%) |
|   Other | 27 (17.6%) | 30 (19.6%) |
|   Missing / Not reported | 1 (0.7%) | 8 (5.2%) |
| **Adjuvant chemotherapy administered** |  |  |
|   Missing / Not reported | 122 (79.7%) | 133 (86.9%) |
|   YES | 29 (19.0%) | 15 (9.8%) |
|   NO | 2 (1.3%) | 5 (3.3%) |
| **Adjuvant radiotherapy administered** |  |  |
|   Missing / Not reported | 122 (79.7%) | 133 (86.9%) |
|   NO | 17 (11.1%) | 13 (8.5%) |
|   YES | 14 (9.2%) | 7 (4.6%) |
| **Overall survival status** |  |  |
|   0:LIVING | 132 (86.3%) | 139 (90.8%) |
|   1:DECEASED | 21 (13.7%) | 14 (9.2%) |
| Overall survival (months) | 38.9 +/- 32.1 (median 28.5, range 0-133, n=153) | 44.4 +/- 41.0 (median 32.2, range 0-281, n=152) |
| **Disease-free status** |  |  |
|   0:DiseaseFree | 125 (81.7%) | 131 (85.6%) |
|   1:Recurred/Progressed | 20 (13.1%) | 15 (9.8%) |
|   Missing / Not reported | 8 (5.2%) | 7 (4.6%) |
| Disease-free survival (months) | 36.8 +/- 31.1 (median 25.0, range 0-133, n=145) | 40.0 +/- 38.1 (median 28.0, range 0-281, n=146) |
