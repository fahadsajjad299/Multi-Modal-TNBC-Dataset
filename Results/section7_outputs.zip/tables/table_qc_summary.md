| QC characteristic | TNBC (Label=1) | Luminal A (Label=0) |
| --- | --- | --- |
| FFPE status = NO | 153 | 153 |
| Sample type = Primary | 153 | 153 |
| Number of distinct tissue source sites | 22 | 18 |
| Confirmed patients (total) | 153 | 153 |
| Patients with linked diagnostic WSI | 146 | 146 |
| Patients without DX WSI indexed in GDC | 7 | 7 |
